import mongoose from 'mongoose'
import jwt from 'jsonwebtoken'
import bcrypt from 'bcrypt'

const userSchema = mongoose.Schema({
    email: {
        required: true,
        type: String,
        unique: true,
        trim: true
    },
    fullname: {
        required: true,
        type: String
    },
    password: {
        required: true,
        type: String,
    },
    savedRecipes: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Recipe"
    }]
}, { timestamps: true })

// FIXED: was "if(this.isModified) return next()" which skipped hashing
userSchema.pre("save", async function (next) {
    if (!this.isModified("password")) return next();
    this.password = await bcrypt.hash(this.password, 10);
    next();
})

userSchema.methods.isPasswordCorrect = async function (password) {
    return await bcrypt.compare(password, this.password);
}

// FIXED: maxAge -> expiresIn for jwt.sign
userSchema.methods.generateAccessToken = function () {
    return jwt.sign(
        { id: this._id },
        process.env.ACCESS_TOKEN_SECRET,
        { expiresIn: '7h' }
    )
}
userSchema.methods.generateRefreshToken = function () {
    return jwt.sign(
        { id: this._id },
        process.env.REFRESH_TOKEN_SECRET,
        { expiresIn: '3d' }
    )
}

export const User = mongoose.model("User", userSchema);
